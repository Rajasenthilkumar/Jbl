export enum Environments {
  DEVELOPMENT = 'development',
  TEST = 'test',
  STAGING = 'stage',
  PRODUCTION = 'production',
}
