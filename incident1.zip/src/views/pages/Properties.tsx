import PropertiesFeature from 'views/features/properties/PropertiesFeature';

const Properties = () => {
  return (
    <div>
      <PropertiesFeature />
    </div>
  );
};

export default Properties;
