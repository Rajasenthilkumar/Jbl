const SignUpTermsAndConditions = () => {
  return (
    <div>
      <h1>Sign Up Terms and Conditions</h1>
      <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque
        voluptates nesciunt in repudiandae sapiente dolores dolor? Iure eligendi
        unde nihil quo? Voluptates accusantium, aliquid placeat id amet mollitia
        minima ullam.
      </p>
    </div>
  );
};

export default SignUpTermsAndConditions;
