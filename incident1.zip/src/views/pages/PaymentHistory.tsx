import PaymentHistoryFeature from 'views/features/profile/PaymentHistoryFeature';

const PaymentHistory = () => {
  return (
    <div>
      <PaymentHistoryFeature />
    </div>
  );
};

export default PaymentHistory;
