const PlatformConnections = () => {
  return <div>PlatformConnections</div>;
};

export default PlatformConnections;
