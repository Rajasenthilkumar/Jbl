import GuestStayFeature from 'views/features/guestStay/GuestStayFeature';

const Stays = () => {
  return (
    <div>
      <GuestStayFeature />
    </div>
  );
};

export default Stays;
