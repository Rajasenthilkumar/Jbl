const AgreeTermsAndConditions = () => {
  return <div>AgreeTermsAndConditions</div>;
};

export default AgreeTermsAndConditions;
