import DocumetLinkFeature from 'views/features/documentLinks/DocumetLinkFeature';

const DocumentsLinks = () => {
  return (
    <div>
      <DocumetLinkFeature />
    </div>
  );
};

export default DocumentsLinks;
