import BookingFeature from 'views/features/bookings/BookingFeature';

const Bookings = () => {
  return (
    <div>
      <BookingFeature />
    </div>
  );
};

export default Bookings;
