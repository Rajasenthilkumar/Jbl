// import { useParams } from 'react-router-dom';
import IncidentReportClaim from '../features/bookings/incidentReport/Host/IncidentReportClaim';

const BookingIncidentReport = () => {
  // const { id } = useParams();
  return (
    <div>
      <IncidentReportClaim id={''} />
    </div>
  );
};

export default BookingIncidentReport;
