const GuestRegionMapCard = () => {
  return (
    <div>
      <p className="pt-4 md:text-lg text-sm font-bold text-black-color">
        Region
      </p>
    </div>
  );
};
export default GuestRegionMapCard;
