const CardComponent = () => {
  return <></>;
};

export default CardComponent;
