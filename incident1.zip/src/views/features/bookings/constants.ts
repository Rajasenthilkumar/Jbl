export const BOOKING_FORM = 2;
