const AssignDocuments = () => {
  return <div>assignDocuments</div>;
};

export default AssignDocuments;
