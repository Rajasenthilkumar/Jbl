import type { FC } from 'react';

type Props = {
  onUploadSuccess: () => void;
};

const AddDocuments: FC<Props> = () => {
  return null;
};

export default AddDocuments;
