const PmsManager = () => {
  return <div />;
};

export default PmsManager;
