export const TOTAL_PMS_MANAGER_STEPS = 3;
export const TOTAL_MANUAL_STEPS = 3;
