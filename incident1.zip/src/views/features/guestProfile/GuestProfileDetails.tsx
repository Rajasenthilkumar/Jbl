const GuestProfileDetails = () => {};
export default GuestProfileDetails;
