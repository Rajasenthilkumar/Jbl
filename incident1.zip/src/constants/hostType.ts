export const HostType = [
  {
    title: 'Owner',
    value: 'Owner',
  },
  {
    title: 'Property Manager',
    value: 'Property Manager',
  },
];
