export const COMPLETE_PROFILE_STORAGE_KEY = 'jbl:skip-profile-complete';
export const LOGIN_STORAGE_KEY = 'jbl:userinfo';
export const REMEMBER_ME_HOST_STORAGE_KEY = 'jbl:remember-me-host';
export const REMEMBER_ME_GUEST_STORAGE_KEY = 'jbl:remember-me-guest';
